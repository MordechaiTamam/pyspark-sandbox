#! /usr/bin/python
import os, sys
import argparse
from pyspark.serializers import CloudPickleSerializer


def rerun(path='', pycharm=False):
    func_pickle   = '%s_func.pckl' % (path)
    print 'func_pickle', func_pickle
    args_pickle   = '%s_args.pckl' % (path)
    kwargs_pickle = '%s_kwargs.pckl' % (path)

    ser = CloudPickleSerializer()

    func = ser.loads(open(func_pickle, 'r').read())
    args = ser.loads(open(args_pickle, 'r').read())
    kwargs = ser.loads(open(kwargs_pickle, 'r').read())

    print 'rerunning', func.__name__, 'with args', args, 'kwargs', kwargs

    if pycharm:
        import pydevd
        pydevd.settrace('localhost', port=21000, stdoutToServer=True, stderrToServer=True)
    res = func(*args, **kwargs)
    print 'result', res
    return res

def parse_args():
    #print sys.argv

    def print_usage():
        print "usage: rerun.py <saved_fails_path> <failed_src_src> -r"

    pycharm = False
    if len(sys.argv) == 4:
        if sys.argv[3] != '-r':
            printUsage()
            sys.exit(1)
        pycharm = True
    elif len(sys.argv) != 3:
        printUsage()
        sys.exit(1)
    func = sys.argv[1]
    src = sys.argv[2]

    return func, src, pycharm

def main():
    '''
    usage: rerun.py <saved_fails_path> <failed_src_src> -r
    '''
    func, src, pycharm = parse_args()

    assert(os.path.isfile(src) or os.path.isdir(src))
    if src not in sys.path:
        sys.path.insert(0, src)
    
    rerun(func, pycharm)

if __name__ == "__main__":
    main()

