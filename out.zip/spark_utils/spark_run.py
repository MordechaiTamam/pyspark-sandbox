#! /usr/bin/python
import requests
import pprint
import json
import argparse
import os
import datetime
import ntpath
import sys
import threading
import signal
import getpass
from spark_utils import is_int
from fails import print_fails
from zip_dirs import zip_dirs
from utils import save_git_state_to_file
import distutils.spawn
import urllib3

from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


is_alive = True
auto_page_thread = None


def print_dt(a, b):
    dt = a - b
    secs = (dt / (1000)) % 60
    mins = (dt / (1000 * 60)) % 60
    hours = (dt / (1000 * 60 * 60)) % 24
    days = (dt / (1000 * 60 * 60 * 24))
    return '%d days and %02d:%02d:%02d ago' % (days, hours, mins, secs)


def signal_handler(signal, frame):
    # if auto_page_thread:
    #     print 'uto_page_thread.isAlive()', auto_page_thread.isAlive()
    #     auto_page_thread.cancel()
    global is_alive
    is_alive = False
    # print('You pressed Ctrl+C!')
    # sys.exit(1)


class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    YELLOW = '\033[93m'
    WHITE = '\033[97m'
    BLUE = '\033[94m'
    RED = '\033[91m'
    GREEN = '\033[92m'


def color_text(loglvl, text=None):
    res = ''
    lvl_dict = {
        'CRITICAL': bcolors.RED,
        'ERROR': bcolors.RED,
        'WARNING': bcolors.YELLOW,
        'WARN': bcolors.YELLOW,
        'INFO': bcolors.GREEN,
        'DEBUG': bcolors.BLUE,
        'NOTEST': bcolors.WHITE,
    }
    out_text = text if text else loglvl
    if loglvl not in lvl_dict.keys():
        return loglvl
    res = '%s%s%s' % (lvl_dict[loglvl], out_text, bcolors.ENDC)
    return res


def pretty_print_POST(req):
    """
    At this point it is completely built and ready
    to be fired; it is "prepared".

    However pay attention at the formatting used in
    this function because it is programmed to be pretty
    printed and may differ from the actual request.
    """
    print('{}\n{}\n{}\n\n{}'.format(
        '-----------START-----------',
        req.method + ' ' + req.url,
        '\n'.join('{}: {}'.format(k, v) for k, v in req.headers.items()),
        req.body,
    ))


class livyRC():
    def __init__(self, host_name, port=3000):
        self.host_name = host_name
        self.port = os.getenv('LIVY_PORT', port)
        self.headers = {'Content-Type': 'application/json'}
        self.bucket_name = '%s%s' % (os.environ['USER'].lower(), datetime.datetime.now().strftime('%Y%m%d%H%M%S%f'))
        self.app_name = self.bucket_name
        print color_text('INFO', 'using LIVY_HOST %s' % self.host_name)

    def upload_file(self, fname):
        if not os.path.isfile(fname):
            print 'No such file : %r ' % fname
            raise Exception()
        key_name = ntpath.basename(fname)
        params = {'bucket': self.bucket_name, 'key': key_name}
        host = 'https://%s:%d/files' % (self.host_name, self.port)
        try:
            r = requests.post(host, files={'file': open(fname, 'rb')}, data=params, verify=False)
        except requests.exceptions.ConnectionError as e:
            print 'Error :: There seems to be a connection error, please check connection and server avaiability'
            print e
            sys.exit(1)
        if r.status_code == 500:
            print 'Error:: Sorry, server error, please verify all services are up and running (status_code = 500)'
            print '%r ' % r.content
            sys.exit(1)
        res_dict = json.loads(r.text)
        if not res_dict['err']:
            return res_dict['handle']
        raise Exception()

    def run(self, fname, pyFiles, fileArgsDict, argsDict, raw_mode=False, num_attempts=0, conf_dict=None):
        furl = self.upload_file(fname)
        if conf_dict is None:
            conf_dict = {}
        args_list = ['--app_name', "%s_%s" % (os.path.split(fname)[1], self.app_name)]
        if num_attempts:
            args_list += ['--max_runs', num_attempts]
        for k, v in argsDict.items():
            args_list += ['--' + k, v]
        for k, v in fileArgsDict.items():
            file_url = self.upload_file(v)
            args_list += ['--' + k, file_url]
        data = {'file': furl, 'args': args_list}
        if pyFiles:
            pyFiles_url = self.upload_file(pyFiles)
            data['pyFiles'] = [pyFiles_url]
            if not raw_mode:
                import zipfile
                archive = zipfile.ZipFile(pyFiles, 'r')
                gtsam_ver = archive.read('mepy_algo/appcode/REM/map_optimization/gtsam').split('/')[5]
                gtsam_repos = '/mnt/efs/rem/gtsam_versions/'
                gtsam_path = gtsam_repos + gtsam_ver + '/gtsam/'
                conf_dict['spark.driver.extraLibraryPath'] = gtsam_path
                conf_dict['spark.executorEnv.LD_LIBRARY_PATH'] = gtsam_path
        data['conf'] = conf_dict

        host = 'https://%s:%d/batches' % (self.host_name, self.port)
        r = requests.post(host, data=json.dumps(data), headers=self.headers, verify=False)
        if r.status_code == 500:
            print 'Error:: Sorry, server error, please verify all services are up and running (status_code = 500)'
            print '%r ' % r.content
            return
        print 'Started batch %r with driver ID %r, application name is %s' % (
            r.json()['id'], r.json()['driverId'], self.app_name)

        return r.json()['id']

    def print_log(self, bid):
        log_str = self.get_log(bid)
        # print str(r)
        print log_str

    def print_ilog(self, bid):
        self.get_ilog(bid)

    def get_log(self, bid):
        data = {'from': 0, 'size': 99999999}
        host = 'https://%s:%d/batches/%d/log' % (self.host_name, self.port, bid)
        r = requests.get(host, params=data, verify=False)
        if r.status_code == 404:
            log_str = 'Sorry batch id %d - not found' % bid
        else:
            log_str = json.dumps(r.json(), indent=2)
        return log_str


    def get_ilog(self, bid):
        import time
        data = {'from': 0, 'size': 999999}
        total_size = 0
        while True:
            host = 'https://%s:%d/batches/%d/log' % (self.host_name, self.port, bid)
            try:
                r = requests.get(host, params=data, verify=False)
            except requests.exceptions.ConnectionError as e:
                time.sleep(1)
                print e
                print 'Error: connectionError in spark_utils while getting status %d' % bid
                print "Retrying... This is probably OK"
                sys.stdout.flush()
                continue

            if r.status_code == 404:
                log_str = 'Sorry batch id %d - not found' % bid
                print log_str
                sys.stdout.flush()
                break

            log_length = len(r.json()['log'])
            if log_length > 1:  # and not 0 since it always print ugly stderr
                logs_str = json.dumps(r.json()['log'], indent=0)
                # remove first and last line since they hold the [ and ] and stderr characters
                logs_str = "\n".join(logs_str.split(", \n"))  # remove ugly commas from end of line
                logs_str = "\n".join(logs_str.split("\n")[1:])
                logs_str = "\n".join(logs_str.split("\n")[:-2])

                # Strip quotes from lines
                lines = [l.strip('"') for l in logs_str.split('\n')]
                logs_str = '\n'.join(lines)

                try:
                    # This makes colors to work!
                    logs_str = logs_str.decode('unicode-escape')
                except:
                    # sometimes there are characters that cant be decoded
                    pass

                print logs_str
                sys.stdout.flush()
                total_size = total_size + log_length - 1  # -1 is because livy is not zero based
                data['from'] = total_size

            proxy_obj = self.get_proxy_object(bid)
            if proxy_obj is not None:
                stat_obj = proxy_obj.json()
                if stat_obj is not None:
                    if stat_obj["state"] == 'success':
                        break
                    elif stat_obj["state"] == 'dead':
                        print "Error: Something went wrong. See below."
                        pprint.pprint(stat_obj)
                        break

            time.sleep(1)
        sys.stdout.flush()

    def print_elog(self, bid, offset, count, search):
        queryVar = search if search else ''
        data = {'from': offset, 'size': count, 'queryVar': queryVar}
        host = 'https://%s:%d/batches/%d/elog' % (self.host_name, self.port, bid)
        try:
            r = requests.get(host, params=data, verify=False)
        except requests.exceptions.ConnectionError as e:
            print 'Error :: There seems to be a connection error, please check connection and server avaiability'
            print e
            sys.exit(1)
        if r.status_code != 200:
            print 'Sorry batch id %d - not found - Actual error::' % bid, r.text
            return
        jj = json.loads(r.text)
        # print 'jj', json.dumps(jj, indent=4)
        for j in jj:
            src_name = 'Driver' if j['execid'] == 'DRV' else 'Executor_%s' % j['execid']
            level = color_text(j['level'])
            print_out = '%s %s %s %s %s' % (j['timestamp'], j['appname'], src_name.ljust(10), level, j['message'])
            print print_out

    def auto_page(self, log_source, offset, count):
        global is_alive
        if not is_alive:
            return
        # print "Hey", log_source, offset, count
        res = self.print_spark_log(log_source, offset, count)
        threading.Timer(3.0, self.auto_page, [log_source, offset + res, count]).start()
        # global auto_page_thread
        # try:
        #     auto_page_thread = threading.Timer(1.0, self.auto_page, [log_source, offset+res, count]).start()
        # except:
        #     print 'CaughtException'

    def print_stderr(self, bid, offset, count, search):
        queryVar = search if search else ''
        data = {'from': offset, 'size': count, 'queryVar': queryVar}
        host = 'https://%s:%d/batches/%d/stderr' % (self.host_name, self.port, bid)
        try:
            r = requests.get(host, params=data, verify=False)
        except requests.exceptions.ConnectionError as e:
            print 'Error :: There seems to be a connection error, please check connection and server avaiability'
            print e
            sys.exit(1)
        if r.status_code != 200:
            print 'Sorry batch id %d - not found - Actual error::' % bid, r.text
            return
        jj = json.loads(r.text)
        for j in jj:
            print_out = '%s %s' % (j['timestamp'], j['message'])
            print print_out

    def print_spark_log(self, log_source, offset, count):
        # data = '{"index": "prems_logs", "type": "log", "body": {"from": %d, "size": %d, "sort": ["@timestamp", "offset"],"query": {"constant_score": {"filter": {"bool" : { "must": [{"term": {"tags": "spark_native_log"}}, {"term": {"logsource": "%s"}}]} }} }}}' % (offset, count, log_source)
        data = '{"index": "prems_logs", "type": "native_log", "body": {"from": %d, "size": %d, "sort": ["@timestamp", "offset"],"query": {"constant_score": {"filter": {"bool" : { "must": [{"term": {"tags": "spark_native_log"}}, {"term": {"logsource": "%s"}}]} }} }}}' % (
            offset, count, log_source)
        print 'print_spark_log %r' % data
        # host = 'http://%s:%d/prems_logs/log/_search/' % (self.host_name, self.port)
        host = 'https://%s:%d/search/' % (self.host_name, self.port)
        try:
            r = requests.get(host, data=data, headers=self.headers, verify=False)
        except requests.exceptions.ConnectionError as e:
            print 'Error :: There seems to be a connection error, please check connection and server avaiability'
            print e
            sys.exit(1)
        if r.status_code != 200:
            print 'Sorry - Some sort of error occured', r.status_code
            return 0

        myd = r.json()
        # print 'len(myd[hits][hits])', len(myd['hits']['hits'])
        if len(myd['hits']['hits']) <= 0:
            return 0
        for i, res in enumerate(myd['hits']['hits'], 1):
            rd = res['_source']
            fields = ['logdate', 'microsecond', 'level', 'srcclass', 'logmsg']
            all_there = True
            for f in fields:
                if f not in rd.keys():
                    all_there = False
                    break

            str_out = ''
            if all_there:
                str_out = '%s,%s %s %s: %s' % (
                    rd['logdate'], rd['microsecond'], color_text(rd['level']), rd['srcclass'], rd['logmsg'])
                # print str_out
            else:
                str_out = color_text('DEBUG', res['_source']['message'])
            print offset + i, str_out
        return i

    def run_search(self, search_data):
        data = search_data
        host = 'https://%s:%d/search/' % (self.host_name, self.port)
        try:
            r = requests.get(host, data=data, headers=self.headers, verify=False)
        except requests.exceptions.ConnectionError as e:
            print 'Error :: There seems to be a connection error, please check connection and server avaiability'
            print e
            sys.exit(1)
        if r.status_code != 200:
            print 'Sorry - Some sort of error occured'
            return
        jj = json.loads(r.text)
        print json.dumps(jj, indent=4)

    def print_stat(self, bid):
        r = self.get_proxy_object(bid)
        if r is not None:
            print json.dumps(r.json(), indent=2)

    def get_zip_file(self, bid):
        zip_files = []
        res = self.get_proxy_object(bid)
        json = res.json()
        j_zip = json.get('zip_file')
        try:
            zip_files = list(eval(j_zip))
        except Exception as ex:
            print "got an error while attempting to get zip files\njson:\t{0}\nzip:\t{1}".format(json, j_zip)
            print ex
            raise

        assert (len(zip_files) == 1)  # only expecting 1 file
        return zip_files[0]

    def print_zip_file(self, bid):
        print self.get_zip_file(bid)

    def print_all(self):
        host = 'https://%s:%d/batches' % (self.host_name, self.port)
        r = requests.get(host, verify=False)
        # print json.dumps(r.json(), indent=2)

        myd = r.json()
        print myd.keys()
        for dr_id in sorted(myd.keys(), key=int):
            print 'Driver id:', dr_id, 'name', myd[dr_id]['driver_name'], 'max runs', myd[dr_id][
                'max_runs'], 'num runs', len(myd[dr_id]['batches'])
            for b in range(len(myd[dr_id]['batches'])):
                b_dat = myd[dr_id]['batches'][b]
                print '\t', 'Batch id', b_dat['id'], ', num run', b_dat['num_run'], 'state', b_dat['state'], print_dt(
                    myd[dr_id]['now'], long(b_dat['state_time']))
                # print myd[ind]

                # for majorkey, subdict in myd.iteritems():
                #     print majorkey
                #     for subkey, value in subdict.iteritems():
                #         print subkey, value

    def delete_run(self, bid):
        host = 'https://%s:%d/batches/%d' % (self.host_name, self.port, bid)
        r = requests.delete(host, verify=False)
        if r.status_code == 404:
            print 'Sorry batch id %d - not found' % bid
            return
        print json.dumps(r.json(), indent=2)

    def get_proxy_object(self, bid):
        data = {'from': 0, 'size': 99999999}
        host = 'https://%s:%d/batches/%d' % (self.host_name, self.port, bid)
        try:
            r = requests.get(host, params=data, verify=False)
        except requests.exceptions.ConnectionError as e:
            print 'Error: connectionError in spark_utils while getting status %d' % bid 
            return None

        if r.status_code == 404:
            print 'Sorry batch id %d - not found' % bid
            return None
        return r


def parse_args(arg_string):
    """ Parses strings of comma separated arguments and converts them to dictionaries."""
    # argsDict = dict((k.strip(), v.strip()) for k, v in (item.split('=', 1) for item in args.args.split(',')))
    args_dict = {}
    if arg_string is None:
        return args_dict

    arg_pairs = arg_string.split(',')
    for pair in arg_pairs:
        kwd, val = pair.split('=', 1)
        kwd = kwd.strip()
        val = val.strip()

        if args_dict.has_key(kwd):
            raise Exception("Error: You are passing the same keyword twice.")

        args_dict[kwd] = val

    return args_dict


def main(argv):
    args = get_args()
    rc = livyRC(args.livy_hostname)

    if args.run is not None:
        wrap_and_run(args, rc)
    elif args.log > -1:
        rc.print_log(args.log)
    elif args.ilog > -1:
        rc.print_ilog(args.ilog)
    elif args.elog > -1:
        rc.print_elog(args.elog, args.offset, args.count, args.search)
    elif args.search > -1:
        rc.run_search(args.search)
    elif args.stat > -1:
        rc.print_stat(args.stat)
    elif args.pyFiles and int(args.pyFiles) > -1:
        rc.print_zip_file(int(args.pyFiles))
    elif args.delete > -1:
        rc.delete_run(args.delete)
    elif args.display_all:
        rc.print_all()
    elif args.stderr > -1:
        rc.print_stderr(args.stderr, args.offset, args.count, args.search)
    # elif args.stderr1:
    #     rc.print_stderr1(args.stderr1, args.offset, args.count)
    elif args.spark_server_log:
        rc.print_spark_log('livy', args.offset, args.count)
    elif args.spark_slave_log:
        rc.print_spark_log('slave', args.offset, args.count)
    elif args.auto_page:
        signal.signal(signal.SIGINT, signal_handler)
        rc.auto_page('livy', args.offset, args.count)
    elif args.fails:
        print_fails(argv[0], args.fails)


def wrap_and_run(args, rc=None, conf_dict=None):
    print str(args)

    if rc is None:
        rc = livyRC(args.livy_hostname)


    file_args_dict = parse_args(args.argsFiles)
    args_dict = parse_args(args.args)

    if args.pyFiles and distutils.spawn.find_executable("git") and os.path.isdir(args.pyFiles[0]) and os.path.isdir(os.path.join(args.pyFiles[0], '.git')):
        paths_dict = save_git_state_to_file(args.pyFiles[0])
        file_args_dict.update(paths_dict)

    zn = zip_dirs(args.pyFiles, args.raw)
    py_files = zn if zn else args.pyFiles
    batch_id = rc.run(args.run, py_files, file_args_dict, args_dict, args.raw, args.num_attempts, conf_dict)

    if batch_id is not None and not args.quiet:
        rc.print_ilog(batch_id)


def get_args(args = None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--livy_hostname', help='Livy host name', default=os.getenv("LIVY_HOST_NAME", None))
    parser.add_argument('--created_by_user', help='the ME username this run should be associated to', default=getpass.getuser())

    parser.add_argument('-s', '--stat', default=-1, type=int, help='Display stat of run')
    parser.add_argument('-l', '--log', default=-1, type=int, help='Display log of run')
    parser.add_argument('-e', '--elog', default=-1, type=int, help='Display elog of run')
    parser.add_argument('-i', '--ilog', default=-1, type=int, help='Continuously print log of run')
    parser.add_argument('-x', '--delete', default=-1, type=int, help='Delete run ID')
    parser.add_argument('-d', '--display_all', action='store_true', default=False, help='Display all batches')
    parser.add_argument('-r', '--run', default=None, help='Path to py to run')
    parser.add_argument('-f', '--argsFiles', default=None, help='Ext files')
    parser.add_argument('-a', '--args', default=None, help='Ext args')
    parser.add_argument('-z', '--pyFiles', nargs='*', default=None, help='Path to zipped python files')
    parser.add_argument('-m', '--raw', action='store_true', default=False, help='Run in raw mode')
    parser.add_argument('--fails', default=None,
                        help='get rerun command lines for failed runs. excepts either batch_id')
    parser.add_argument('-o', '--offset', default=0, type=int, help='Offset in log resaults')
    parser.add_argument('-c', '--count', default=100, type=int, help='Number of log resaults')
    parser.add_argument('-w', '--search', default=None, help='Raw search mode')
    parser.add_argument('-t', '--spark_server_log', action='store_true', default=False, help='Get the Spark server log')
    parser.add_argument('-u', '--spark_slave_log', action='store_true', default=False, help='Get the Spark slave log')
    parser.add_argument('-v', '--auto_page', action='store_true', default=False, help='Auto paage')
    parser.add_argument('-n', '--num_attempts', default=0, type=int, help='Number of attempts to run application')
    # parser.add_argument('-g', '--stderr1', default=None, help='Get the stderr of a given application ID')
    parser.add_argument('-b', '--stderr', default=-1, type=int, help='Get the stderr of a given application ID')
    parser.add_argument('-q', '--quiet', action='store_true', help='disables live log')
    parser.add_argument('-j', '--conf_file', action='store_true', help='json_conf_file')
    args = parser.parse_args(args=args)

    if args.livy_hostname is None:
        raise Exception("You need to set a livy hostname. This can be done with an ENV variable ('LIVY_HOST_NAME') or with a cmd argument ('--livy_hostname')")

    return args


if __name__ == "__main__":
    main(sys.argv)
