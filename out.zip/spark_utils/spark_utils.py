from __future__ import division
import os
import sys
import logging
import ast
import json
import errno
import cPickle
import datetime
import time
import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def timebomb(app_name, due_date, sc):
    ignored_timebomb_path = '/mnt/efs/rem/spark_metadata/ignored_timebomb.json'
    while True:
        #print 'inside time bomb: ' + str(due_date)

        # see if need to ignore timebomb for this application
        should_ignore = False
        try:
            with open(ignored_timebomb_path, 'r') as infile:
                data = json.load(infile)
                if (data.get(app_name, False) == True):
                    should_ignore = True
                    print 'ignoring timebomb for application ' + app_name

        except Exception as e:
            print sys.exc_info()
            print 'error: ' + e.message
            pass

        current_time = time.time()
        if ((should_ignore == False) and (current_time > due_date)):
            print 'Error: timebomb original spark cluster due date was: ' +  time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(due_date)) + \
                    '. Spark cluster current date is: ' + time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(current_time)) + \
                    '. About to suicide inside timebomb. This run is longer than declared.'
            os._exit(1)
        time.sleep(60)


# Do not change lines in this function without getting management approval. Even not for a specific run
def safeguards(app_name, max_duration_minutes, cores_num):
    if max_duration_minutes < 0:
        # we ignore this value. It should only be used in streaming applications etc.
        print 'Max duration is negative. We will skip budget control and timebomb. Only use this for streaming application and with permission from management!!!'
        return

    # first we check that we are not asking too much cores
    # default is 5000 cores for 10 hours
    max_allowed = int(os.getenv('MAX_ALLOWED_MINUTE_CPU_RESOUCES', str(5000*60*10)))
    max_duration_minutes = float(max_duration_minutes)
    if (max_duration_minutes*cores_num > max_allowed):
        print 'Error: Such run is not allowed. It is asking for too much resources. Please contact management to get approval. Terminating immidiately!'
        sys.exit(1)

    from threading import Thread
    # now we add timebomb that will monitor the process and will kill it automatically if the max_duration_minutes is exceeded
    due_date = time.time() + max_duration_minutes*60.0
    print 'Timebomb activation: max duration was set to: ' + str(max_duration_minutes) +  ' minute(s)' + \
            '. Spark cluster due date is: ' + time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(due_date)) + \
            '. Spark clutser current date is: ' + time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())) + '.'

    thread = Thread(target = timebomb, args = (app_name, due_date, g_my_context))
    thread.daemon = True # this causes the program to terminate if the parent thread dies. we dont want to wait for timebomb in such case
    thread.start()


def init_spark_logging():
    global logger
    logger = logging.getLogger('prems_spark_log')
    if os.environ.has_key('PREMS_LOG_PATH') & os.environ.has_key('HOSTNAME'):
        log_name = '%s/prems_sparkLog_%s_%d_%s_%s.log' % (
        os.environ['PREMS_LOG_PATH'], os.environ['HOSTNAME'], os.getpid(), get_app_name(), 'DRV')
        handler = logging.FileHandler(log_name)
    else:
        handler = logging.StreamHandler(sys.stdout)

    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)


g_app_name = None
g_my_context = None
g_my_session = None
g_max_cores = 0


def get_zip_fname():
    '''
    finds the out.zip file with the following unsafe ussmptions:
    1. The tree was zipped into 'out.zip'
    2. If invoked through the CLI then the out.zip file in located 5 levels before import_gtsam.py
    3. If invoked through PyCharm's remote interpreter there is the TREE_ROOT enviroment variable
       that points at out.zip location
    :return: the apth to out.zip
    '''
    if os.getenv('TREE_ROOT'):
        return os.path.join(os.getenv('TREE_ROOT'), 'out.zip')

    dir_path = os.path.dirname(os.path.realpath(__file__))
    return os.path.join('/'.join(dir_path.split('/')[:-5]), 'out.zip')


def locate_gtsam():
    zip_fname = get_zip_fname()
    import zipfile
    archive = zipfile.ZipFile(zip_fname, 'r')
    gtsam_ver = archive.read('mepy_algo/appcode/REM/map_optimization/gtsam').split('/')[5]
    gtsam_repos = '/mnt/efs/rem/gtsam_versions/'
    req_gtsam_path = gtsam_repos + gtsam_ver

    return req_gtsam_path


def set_app_name():
    global g_app_name
    index = -1
    if sys.argv.count('--app_name'):
        index = sys.argv.index('--app_name')

    if (index >= 0):
        # the spark_run case
        g_app_name = sys.argv[index + 1]
    else:
        # the pycharm case
        tree_root = os.getenv('TREE_ROOT', 'NO_ROOT')
        user_name = 'unknownuser'
        user_dir_prefix = '/mnt/efs/rem/users/'
        if tree_root.startswith(user_dir_prefix):
            user_name = tree_root[len(user_dir_prefix):]
            user_name = user_name[:user_name.find('/')]
        g_app_name = 'DefaultAppName_%s_%s' % (user_name, datetime.datetime.now().strftime('%Y%m%d%H%M%S%f'))

def get_app_name():
    return g_app_name


def get_logger():
    return logging.getLogger('prems_spark_log')


def update_application_id(app_id, retries=30):
    default_livy_host = 'localhost:3000'
    livy_host = os.getenv('LIVYPROXYURL', default_livy_host)
    hdrs = {'Content-Type': 'application/json'}

    if "https://" not in livy_host:
        livy_host = 'https://' + livy_host

    host = '{}/update/applicationid'.format(livy_host)
    data = {'driver_name': get_app_name(), 'application_id': app_id}
    try:
        requests.post(host, data=json.dumps(data), headers=hdrs, timeout=30, verify=False)
    except requests.exceptions.ConnectionError as e:
        print "Unexpected error update application id:", host, sys.exc_info()[0]
        print e
        if retries == 0:
            return
        time.sleep(15)
        update_application_id(app_id, retries - 1)


def get_allocated_cores(app_id, retries=30):
    default_livy_host = 'localhost:3000'
    livy_host = os.getenv('LIVYPROXYURL', default_livy_host)
    hdrs = {'Content-Type': 'application/json'}

    # print livy_host
    # print app_id
    host = '%s/applications/%s/nodes-count' % (livy_host, app_id)
    # print host

    data = {'app_id': app_id}
    try:
        res = requests.get(host, data=json.dumps(data), headers=hdrs, timeout=30, verify=False)
        # print res.text
        return int(json.loads(res.text)['totalCores'])
    except:
        print "Unexpected error - allocated cores:", host, sys.exc_info()[0]
        if retries == 0:
            return 0
        time.sleep(15)
        return get_allocated_cores(app_id, retries - 1)


def calc_max_cores(max_cores):
    round_to = 0
    try:
        round_to = int(os.environ['SPARK_EXECUTOR_CORES'])
    except:
        round_to = 1

    return max_cores + ((round_to - (max_cores % round_to)) % round_to)


def generate_spark_session(max_cores=36, should_wait=False, max_duration_minutes=60):
    from pyspark.sql import SparkSession

    global g_my_session

    # sc = g_my_context if g_my_context else generate_spark_context(max_cores, should_wait)
    sc = generate_spark_context(max_cores=max_cores, should_wait=should_wait, max_duration_minutes=max_duration_minutes)
    g_my_session = SparkSession(sc)
    return g_my_session


def generate_spark_context(max_cores=None, should_wait=False, spark_conf=None, max_duration_minutes=60*10):
    from pyspark import SparkContext
    from pyspark.serializers import CloudPickleSerializer
    from time import time
    from pyspark import SparkConf


    init_spark_logging()

    if not spark_conf:
        spark_conf = SparkConf()

    if max_cores:
        spark_conf.set('total-executor-cores', max_cores)

    global g_my_context
    global g_max_cores

    pyFiles = None

    if g_my_context:
        msg = 'Error trying to create spark context twice'
        print msg
        raise Exception(msg)

    pycharm_debug = os.getenv('PYCHARM_DEBUG', False)

    logging.getLogger('py4j').setLevel(logging.ERROR)
    master = os.getenv('SPARKMASTER', 'local')

    # Fair scheduling
    SparkContext.setSystemProperty("spark.scheduler.mode", "FAIR")
    max_cores = int(spark_conf.get("total-executor-cores"))
    max_cores_rounded = calc_max_cores(max_cores)
    g_max_cores = max_cores_rounded
    logger.info('setting max cores. asked max cores were: {}. rounded up max cores are: {}'.format(max_cores,max_cores_rounded))

    # setting max cores
    SparkContext.setSystemProperty("spark.cores.max", str(max_cores_rounded))
    SparkContext.setSystemProperty("spark.sql.execution.arrow.enabled", "True")

    if pycharm_debug:
        # information for Sparkcontext creation:
        from zip_dirs import zip_dirs
        zip_dirs(dir_paths=[os.getenv('TREE_ROOT') + '/mepy_algo'], out_dir=os.getenv('TREE_ROOT'))
        gtsam_path = os.path.join(locate_gtsam(), 'gtsam')
        pyFiles = ['file:' + get_zip_fname()]

        SparkContext.setSystemProperty('spark.driver.extraLibraryPath', gtsam_path)
        SparkContext.setSystemProperty('spark.executorEnv.LD_LIBRARY_PATH', gtsam_path)
        SparkContext.setSystemProperty('spark.driver.extraJavaOptions',
                                       '-Djavax.jdo.option.ConnectionURL=jdbc:derby:;databaseName=/tmp/derby_%d/metastore_db;create=true' % int(
                                           time()))

    # theses needs to be set explicitylu since these variables should only work for yarn and not standalone
    # for some unknown weird reason they work when submitted through livy
    exec_cores = os.getenv('SPARK_EXECUTOR_CORES')
    exec_memory = os.getenv('SPARK_EXECUTOR_MEMORY')

    if exec_cores:
        SparkContext.setSystemProperty('spark.executor.cores', exec_cores)
    if exec_memory:
        SparkContext.setSystemProperty('spark.executor.memory', exec_memory)

    logger.info('overwriting spark context configurations with: {0}'.format((
        "\n".join(str(v) for v in spark_conf.getAll()))))


    # these 2 functions needs to be called before generate_spark_context
    set_app_name()
    safeguards(g_app_name, max_duration_minutes, max_cores_rounded)


    g_my_context = SparkContext(master, g_app_name, pyFiles=pyFiles, serializer=CloudPickleSerializer(),conf=spark_conf)
    g_my_context.setLogLevel("WARN")
    logger.info('generate_spark_context app_name: {0}'.format(g_app_name))

    logger.info('prems_driver up and running')
    appId = g_my_context._jsc.sc().applicationId()
    logger.info('Application ID: %s, application name is: %s', appId, get_app_name())
    update_application_id(appId)

    # saving max cores in a file so that later on the machine allocator  can save time
    # in figuring it instead of accessing the history server
    max_cores_path = '/mnt/efs/rem/applications_metadata/'

    os.system('mkdir -p ' + max_cores_path + '; chmod 0777 -R ' + max_cores_path + '; echo ' + str(
        max_cores_rounded) + ' > ' + max_cores_path + appId)
    os.system('chmod 0666 ' + max_cores_path + appId)

    if should_wait:
        wait_for_cores(g_my_context, lambda x: x, [])

    return g_my_context


def wait_for_cores(spark_context, callback_when_cores_available, params):
    # wait for g_max_cores to be available
    global g_max_cores
    alloc_cores = 0

    while g_max_cores > alloc_cores:
        time.sleep(10)
        alloc_cores = get_allocated_cores(spark_context._jsc.sc().applicationId())
        print('{}/{} cores allocated: {}%'.format(alloc_cores, g_max_cores, int(alloc_cores/g_max_cores * 100)))

    callback_when_cores_available(params)



def get_spark_context():
    return g_my_context


def read_params_file(params_file):
    try:
        with open(params_file, 'r') as f:
            return ast.literal_eval(f.read().replace('\n', '').strip())
    except ValueError:
        with open(params_file, 'r') as f:
            return json.load(f)
    except:
        raise Exception('cannot parse')


def mkdir_p(path):
    try:
        os.makedirs(path)
    except OSError as exc:  # Python >2.5
        if exc.errno == errno.EEXIST and os.path.isdir(path):
            pass
        else:
            raise


def is_int(x):
    try:
        int(x)
        return True
    except ValueError:
        return False


class run_state():
    def __init__(self, fname):
        self.fname = fname
        self.fin_steps = []
        if os.path.isfile(self.fname):
            self.fin_steps = cPickle.load(open(self.fname, 'rb'))
        self.cur_step = None

    def reset(self):
        self.fin_steps = []
        self.cur_step = None
        if os.path.isfile(self.fname):
            os.remove(self.fname)

    def dump_state(self):
        if self.cur_step is not None:
            self.fin_steps.append(self.cur_step)

        cPickle.dump(self.fin_steps, open(self.fname, 'wb'))

    def run(self, step_name):
        run_step = True
        if step_name in self.fin_steps:
            run_step = False
        if run_step:
            self.dump_state()
            self.cur_step = step_name
        print 'Run %s ? %r' % (step_name, run_step)
        return run_step

    def done(self):
        os.remove(self.fname)


if __name__ == '__main__':
    generate_spark_context(5)
