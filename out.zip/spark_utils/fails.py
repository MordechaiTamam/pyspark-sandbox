#! /usr/bin/python
import requests
import json
import os
import sys
from subprocess import call
from spark_utils import is_int

host_name = os.getenv('LIVY_HOST_NAME', 'localhost')
port = os.getenv('LIVY_PORT', 3000)

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    YELLOW = '\033[93m'
    WHITE = '\033[97m'
    BLUE = '\033[94m'
    RED = '\033[91m'
    GREEN = '\033[92m'


def color_text(loglvl, text=None):
    res = ''
    lvl_dict = {
        'CRITICAL': bcolors.RED,
        'ERROR': bcolors.RED,
        'WARNING': bcolors.YELLOW,
        'WARN': bcolors.YELLOW,
        'INFO': bcolors.GREEN,
        'DEBUG': bcolors.BLUE,
        'NOTEST': bcolors.WHITE,
    }
    out_text = text if text else loglvl
    if loglvl not in lvl_dict.keys():
        return loglvl
    res = '%s%s%s' % (lvl_dict[loglvl], out_text, bcolors.ENDC)
    return res

def get_batchid(arg):
    if is_int(arg):
        return int(arg)
    else:
        assert (0)

def get_fails(bid):
    host = 'http://%s:%d/batches/%d/fails' % (host_name, port, bid)
    r = requests.get(host)
    if r.status_code == 404:
        print 'Sorry batch id %d - not found' % bid
        return

    return r.json()

def print_fails(basename, bid, dest='~/tmp/fails'):
    path = os.path.dirname(basename)
    print basename, bid
    batchid = get_batchid(bid)
    fails = get_fails(batchid)
    files = eval(fails['files'])
    if len(files) == 0:
        print 'No fails for run'
        return

    get = os.path.join(path, 'get-src.sh')
    src = fails['zip_file'][1:-1]
    dest = os.path.join(dest, fails['drv_name'])

    print color_text('INFO', '* copying source code from: %s to: %s' % (src, dest))
    cmd = '%s %s %s > /dev/null' % (get, src, dest)
    call(cmd, shell=True)

    print
    print color_text('INFO', 'failed paths from batch %d app name %s' % (batchid, fails['drv_name']))
    for fn in files:  # turn string into list
        print '"%s"' % fn[:fn.index('_func.pckl')]#.replace('<lambda>', '\<lambda\>')

    print
    print color_text('INFO', '* PyCharm mappings: %s %s' % (dest, src)) 
    call('ZIP_FILE=%s ./rerun-ssh.sh' % src, shell=True)


def main(argv):
    print_fails(path, batchid)


if __name__ == "__main__":
    main(sys.argv)

