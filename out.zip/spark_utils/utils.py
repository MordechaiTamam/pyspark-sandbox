import os
import subprocess


def run_cmd_and_get_output(cmd):
    """cmd should be a list"""
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE)
    out, err = p.communicate()
    return out, err


def save_git_state_to_file(git_repo_base):
    """Saves the state of git into a simple text file. This is for reproducibility as it allows users to later see the
    state of a repo when a step was run"""
    paths_dict = {
        'git_status_path': os.path.join(git_repo_base, "git_status.txt"),
        'git_diff_path': os.path.join(git_repo_base, "git_diff.txt"),
        'git_log_path':  os.path.join(git_repo_base, "git_log.txt"),
    }

    with open(paths_dict['git_status_path'], "wb") as f:
        out, err = run_cmd_and_get_output(['git', 'status'])
        f.write(out)
        f.write(err)

    with open(paths_dict['git_diff_path'], "wb") as f:
        out, err = run_cmd_and_get_output(['git', 'diff'])
        f.write(out)
        f.write(err)

    with open(paths_dict['git_log_path'], "wb") as f:
        out, err = run_cmd_and_get_output(['git', 'log', '-n', '50'])
        f.write(out)
        f.write(err)

    return paths_dict
