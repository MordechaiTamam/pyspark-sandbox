import traceback
import sys
import logging
import os
import urlparse
import spark_utils
from pyspark.serializers import CloudPickleSerializer

first_time = True
fail_info = None
task_id = 0

# wraps func in a way that no exception will be thrown - collecting the
# exception and reporting it later
def prems_mapper(func, stage='UNKNOWN_TASK'):
    app_name = spark_utils.get_app_name()

    def myFunction(*args, **kwargs):
        final_res = {'value': None, 'failed': False, 'error_details': None}

        logger = logging.getLogger('prems_spark_log')
        logger.setLevel(logging.DEBUG)
        global first_time
        if first_time:
            first_time = False
            url = os.environ.get('SPARK_LOG_URL_STDERR',"NO URL in SPARK_LOG_URL_STDERR")

            parsed = urlparse.urlparse(url)
            args_dict = urlparse.parse_qs(parsed.query)
            global fail_info
            executor_id = args_dict.get('executorId',[-1])[0]
            fail_info = {'path' : app_name, 'executer':'%s_%s'%(executor_id , os.getpid())}
            prems_log_path = os.environ.get('PREMS_LOG_PATH', None)
            if prems_log_path:
                host_name = os.environ.get('HOSTNAME', "NO HOSTNAME")
                log_name = '%s/prems_sparkLog_%s_%d_%s_%s.log' % (prems_log_path, host_name, os.getpid(), app_name, executor_id )
                if not os.path.isfile(log_name):
                    fh = logging.FileHandler(log_name)
                    fh.setLevel(logging.DEBUG)
                    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
                    fh.setFormatter(formatter)

                    logger.addHandler(fh)

        logger.info('prems_mapper gonna run func - %r for %r, with args %r and kwargs %r %r %r' % (func.__name__, stage, args, kwargs, os.getpid(), os.getppid()))
        try:
            final_res['value'] = func(*args, **kwargs)
        except Exception as e:
            T, V, TB = sys.exc_info()
            logger.error('Got an error:\n{0}'.format(e))
            save_fail(fail_info, stage, func, args, kwargs)
            final_res['failed'] = True
            error_details = {
                'excpetion_trace': ''.join(traceback.format_exception(T, V, TB)),
                'exception': e,
                'log_fail': 'fail_save_path: %s stage: %s func: %s args %s' % (fail_info['path'], stage, func.__name__, args)
            }
            final_res['error_details'] = error_details
            logger.error('Error - excpetion happened: ' + str(e))
            logger.error(error_details['excpetion_trace'])
            logger.error(error_details['log_fail'])

        logger.info('prems_mapper finished run func - %r for %r - success? %r' % (func.__name__, stage, not final_res['failed']))

        return final_res
    logger = logging.getLogger('prems_spark_log')
    logger.info('Mapp for task - %s' % stage)
    return myFunction

def save_fail(fail_info, stage, func, args, kwargs):
    try:
        root = '/mnt/efs/rem' #TODO: get root path from env
        path = os.path.join(root, 'fails', fail_info['path'])
        spark_utils.mkdir_p(path)
          
        global task_id 
        name_str = '%s/%s_e%s_c%d_' % (path, func.__name__, fail_info['executer'], task_id)
        func_pickle     = name_str + 'func.pckl'
        args_pickle     = name_str + 'args.pckl'
        kwargs_pickle   = name_str + 'kwargs.pckl'
        task_id += 1

        ser = CloudPickleSerializer()

        open(func_pickle, 'wb').write(ser.dumps(func))
        open(args_pickle, 'wb').write(ser.dumps(args))
        open(kwargs_pickle, 'wb').write(ser.dumps(kwargs))
    except Exception as ex:
        import traceback
        traceback.print_exc()
        logger = logging.getLogger('prems_spark_log')
        logger.error('save_fail failed:\n {0}' % ex)

def prems_values(arr):
    final_arr = [x for x in arr if x['failed'] is False]
    return final_arr

def prems_success_values(arr):
    success_items = prems_values(arr)
    values = [x['value'] for x in success_items]
    return values

def prems_exceptions(arr):
    success_items = prems_values(arr)
    failed_items = [x for x in arr if x not in success_items]
    err_details = [x.get('error_details',{}) for x in failed_items]
    exs = [(x.get('exception',None), x.get('excpetion_trace',None)) for x in err_details]
    return [ex for ex in exs if ex is not None]



# used for reduce counting of failed
def is_failed(old_value, prems_task_res):
    if (prems_task_res['failed']):
        return 1 + old_value
    return old_value


def count_failed(arr):
    return reduce(is_failed, arr, 0)


def prems_success_percent(arr):
    num_failed = count_failed(arr)
    return (1.0 - num_failed/float(len(arr)))*100


# The following are just some tests to see that everything works as expected
def myMapperFunction(value1):
    if (value1 > 4):
        raise Exception('whatever')
    return value1


def main():
    arr = [1, 2, 3, 4, 5, 6]
    res = map(prems_mapper(myMapperFunction), arr)
    values = prems_values(res)
    print prems_success_percent(res)
    print values


if __name__ == '__main__':
        main()
