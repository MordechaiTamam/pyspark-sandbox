#! /usr/bin/python

import sys
import json
import argparse
import requests
import subprocess
import os
import time
from zip_dirs import zip_dirs
from spark_utils import mkdir_p


def create_interpreter(local_dir, path):
    oname = local_dir + '/python_interpreter.sh'
    lines = open('python_interpreter.template', 'r').readlines()
    for i in xrange(len(lines)):
        lines[i] = lines[i].replace('USER_PATH', path)

    with open(oname, 'w') as f:
        f.writelines(lines)

    return oname


def cleanup_and_exit(local_dir, exit_code):
    # remove tmp zip
    if not local_dir.startswith('/tmp/'):
        print 'Error: cannot clean a local dir that is not in tmp dir. Too risky...' + local_dir
    else:
        subprocess.call('rm -rf ' + local_dir, shell=True)

    sys.exit(exit_code)


def get_tree_root():
    res = subprocess.check_output(['git', 'rev-parse', '--show-toplevel']).strip()
    if os.path.isdir(res):
        return res
    return None


def main(argv):
    parser = argparse.ArgumentParser()
    parser.add_argument('-u', '--user', default=os.environ['USER'].lower(), help='The username')
    parser.add_argument('-e', '--extra_path', default="", help='Extra path - if the user has more than one tree')
    parser.add_argument('-t', '--tree', default=get_tree_root(), help="Path to the tree u want  to deploy")
    parser.add_argument('-c', '--cluster', default="rem-dev", help="Path to the cluster to deploy to")
    args = parser.parse_args()

    local_dir = '/tmp/%d/' % int(time.time()*1000)
    local_zip = os.path.join(local_dir, 'out.zip')
    deploy_path = '/mnt/efs/rem/users/%s/%s' % (args.user, args.extra_path)
    mkdir_p(local_dir)
    interpreter = create_interpreter(local_dir, deploy_path)

    if args.tree is None or (not os.path.isdir(args.tree)):
        parser.print_help()
        print "@@@ Error: tree is mandatory and must be a valid directory. "
        cleanup_and_exit(local_dir, 1)

    print 'Deploying tree: ' + args.tree + ' into the cluster ' + args.cluster + ' (might take a while):'
    print "Zipping into tmp local dir: " + local_dir

    zip_dirs(dir_paths=[args.tree], out_dir=local_dir)

    if args.cluster == 'localhost':
        ip = args.cluster
    else:
        # print '@@@ %r' % livy_nodes
        ip = 'driver1.' + args.cluster + '.remdevme.com'  # livy_nodes[0]['publicIp']

    ssh = 'ssh -q -i ~/.ssh/prems_ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -p 4043 root@%s ' % (ip)

    # remove old deploy_path
    print 'Cleaning remote dir...'
    remote_dir = deploy_path + '/' + args.tree
    spark_utils_dir = deploy_path + '/spark_utils'
    subprocess.call(ssh + '"rm -rf %s %s"' % (remote_dir, spark_utils_dir), shell=True)
    # create deploy dir on remote efs
    print 'Creating remote dir...'
    subprocess.call(ssh + '"mkdir -p %s"' % deploy_path, shell=True)
    # copy zip to remote efs
    print 'Copying zip file remotely...'
    cmd = 'scp -i ~/.ssh/prems_ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -P 4043 %s root@%s:%s' % (local_zip, ip, deploy_path)
    subprocess.call(cmd, shell=True)
    print 'Copying python interpreter setting...'
    cmd = 'scp -i ~/.ssh/prems_ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -P 4043 %s root@%s:%s' % (interpreter, ip, deploy_path)
    subprocess.call(cmd, shell=True)

    # unzip on remote efs
    print 'Unzip zip remotely (takes a while)...'
    subprocess.call(ssh + '"cd %s; unzip -o -u out.zip > /dev/null"' % deploy_path, shell=True)

    print '\033[32madd to pycharm deployment host: \033[96m%s' % ip
    print '\033[32madd to pycharm interpreter(Python interpreter path): \033[96m%s' % os.path.join(deploy_path, os.path.basename(interpreter))

    cleanup_and_exit(local_dir, 0)

if __name__ == "__main__":
    main(sys.argv)
