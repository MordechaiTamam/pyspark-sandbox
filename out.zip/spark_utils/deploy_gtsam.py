#! /usr/bin/python

import sys
import json
import argparse
import requests
import os

def call_wait(cmd):
    '''
    subprocess.call wait for child process to end.
    but for some reason subprocess.call doesn't work exactly like os.system (?!?!)
    '''
    try:
       os.system(cmd)
       os.wait() 
    except oserror as e:
       pass
    
def find_ip_of_livy(cluster_name, retries=5):
    url = 'http://admin.' + cluster_name + '.remdevme.com:3000/livy_nodes'
    try:
        r = requests.get(url)
        if r.status_code != 200:
            raise
        return json.loads(r.text)
    except:
        print "@@@ Unexpected error - allocated cores:", url, sys.exc_info()[0]
        if retries == 0:
            return []
        time.sleep(20)
        return find_ip_of_livy(cluster_name, retries-1)

def tar_gtsam(tree):

    gtsam_link = os.path.join(tree, 'appcode/REM/map_optimization/gtsam')
    gtsam_path = os.path.realpath(gtsam_link)
    gtsam_ver = gtsam_path.split('/')[-2]
    local_tar = '/tmp/{}.tgz'.format(gtsam_ver)
    cmd = 'cd /mobileye/shared/gtsam/gtsam_versions; tar czfh {} {}'.format(local_tar, gtsam_ver+'/lib')
    print cmd
    call_wait(cmd) 
    return local_tar 

def main(argv):
    parser = argparse.ArgumentParser()
    parser.add_argument('-t', '--tree', required=True, help="Path to mepy_algo")
    parser.add_argument('-c', '--cluster', default="rem-dev", help="Path to the cluster to deploy to")
    parser.add_argument('-f', '--find_livy', action="store_true", help="find ip of livy and exit")
    args = parser.parse_args()

    deploy_path = '/mnt/efs/rem/gtsam_versions/'

    if not os.path.isdir(args.tree):
        parser.print_help()
        print "@@@ Error: tree is mandatory and must be a valid directory. "

    local_tar = tar_gtsam(args.tree)
    tar_name = os.path.basename(local_tar)
    version = os.path.splitext(tar_name)[0]

    livy_nodes = find_ip_of_livy(args.cluster)
    if livy_nodes is None or len(livy_nodes) == 0:
        print "@@@ Error: cannot find a running livy machine in cluster: " + \
            args.cluster + '. make sure it is up with spark module enabled'

    # print '@@@ %r' % livy_nodes
    ip = 'driver1.' + args.cluster + '.remdevme.com'  # livy_nodes[0]['publicIp']
    scp = 'scp -i ~/.ssh/prems_ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -P 4043 %s root@%s:%s' % (local_tar, ip, deploy_path)
    ssh = 'ssh -q -i ~/.ssh/prems_ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -p 4043 root@%s ' % (ip)
    
    print 'Copying tar file remotely...'
    print scp
    call_wait(scp)

    # remove old deploy_path
    remote_dir = os.path.join(deploy_path, version) 
    print 'Cleaning remote dir...', remote_dir
    call_wait(ssh + '"rm -rf %s"' % remote_dir)
    
    cmd = '"mkdir -p {path}; ' + \
          'cd {path}; ' + \
          'tar xzf {tar}; ' + \
          'chown -R root:root {ver}; ' + \
          'mv {ver}/lib {ver}/gtsam"'

    print 'Deploying gtsam into cluster ' + args.cluster
    deploy = ssh + cmd.format(path=deploy_path, tar=tar_name, ver=version)
    call_wait(deploy)

    print 'Removing local tar file'
    cmd = 'rm -rf {}'.format(local_tar)
    call_wait(cmd)

if __name__ == "__main__":
    main(sys.argv)
