import os
import sys
import time
from subprocess import call

def call_wait(cmd):
    '''
    subprocess.call wait for child process to end.
    but for some reason subprocess.call doesn't work exactly like os.system (?!?!)
    '''
    try:
        #print cmd
        call(cmd, shell=True, executable='/bin/bash')
    except OSError as e:
        print >> sys.stderr, 'Execution failed:', e
        pass
    
def zip_gtsam(dirs, zip_name):
    '''
    Add link to gtsam (the gtsam version) into zip file so it could be found in the cloud
    '''

    mepy_algo_dirs = set()
    offset = len('mepy_algo')
    for d in dirs:
        abs_dir = os.path.abspath(d)
        index = abs_dir.rfind('mepy_algo')
        if index > -1:
            mepy_algo_dirs.add(abs_dir[:index+offset])

    if len(mepy_algo_dirs) > 1:
        print 'found multiple references to mepy_algo:', list(mepy_algo_dirs), 'using the first' 

    if(len(mepy_algo_dirs)>0):
        mepy_algo = mepy_algo_dirs.pop()
        gtsam_loc = mepy_algo + '/appcode/REM/map_optimization/gtsam'

        if not os.path.exists(gtsam_loc) and not os.path.islink(gtsam_loc):
            raise Exception("Could not find %s" % gtsam_loc)

        # we want to cd to 1 level above the dir_path and add the dir_path to the zip
        head, tail = os.path.split(os.path.realpath(os.path.normpath(mepy_algo)))
        gtsam_rel_path = tail + '/appcode/REM/map_optimization/gtsam'
        call_wait('pushd %s > /dev/null; zip --symlinks -gq %s %s; popd > /dev/null' % (head, zip_name, gtsam_rel_path)) #-y don't follow symlink

def zip_dir(dir_path, zip_name):
    if not dir_path or not os.path.isdir(dir_path):
        print "directory %s doesn't exist" % dir_path
        raise Exception("Error directory %s doesn't exist" % dir_path)

    # we want to cd to 1 level above the dir_path and add the dir_path to the zip
    head, tail = os.path.split(os.path.realpath(os.path.normpath(dir_path)))
    start = time.clock()
    call_wait('pushd %s > /dev/null; zip -rqy %s * -i \'./%s/*.py\'; popd > /dev/null' % (head, zip_name, tail)) #-y don't follow symlink
    print 'zip took', time.clock()-start

def zip_dirs(dir_paths, skip_gtsam=False, out_dir=None):
    '''
    Zip a list of directories.
    Also include the spark_utils directory inside the zip
    Returns the name of the zip file created
    '''
    zip_name = os.path.realpath('out.zip') 
    if not dir_paths:
        return None

    if os.path.isfile(zip_name):
        os.remove(zip_name)

    print 'out_dir', out_dir
    if out_dir:
        if not os.path.isdir(out_dir):
            print 'out_dir %s does not exist' % out_dir
            return None
        else:
            zip_name = os.path.realpath(os.path.join(out_dir, 'out.zip'))

    # add all dirs to the zip command
    for dir_path in dir_paths:
        print 'zipping dir', dir_path
        zip_dir(dir_path, zip_name)

    # add gtsam to the zip command
    if not skip_gtsam:
        zip_gtsam(dir_paths, zip_name)

    # add spark_utils dir to the zip command
    spark_utils_path = os.path.dirname(os.path.realpath(__file__))
    zip_dir(spark_utils_path, zip_name)

    print 'zip_name', zip_name
    return zip_name


